package software;

/**
 *
 * @author Kyle Hogue
 */

/**
 *  RUNTIME ERROR DESCRIPTION NEAR CODE IN Modify_Product_Controller.java Line 125
 *
 *  FUTURE FEATURE COMMENT!
 *
 *      Adding an extra TableView to the main page to show associated parts when selecting a specific product.
 *      As the program currently is, the only way to see associated parts of a specific product is to select ->
 *      modify which introduces the potential for a miss-click or bad keystroke to unintentionally modify data.
 *
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("Main_form.fxml"));
        primaryStage.setTitle("Inventory Management Software");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
